package com.crm.qa.testcases;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import io.restassured.path.json.JsonPath;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.testng.annotations.Test;

public class Testcase1 {
@Test
public void test() throws IOException, ParseException {
	String file = System.getProperty("user.dir")+"\\src\\main\\resources\\TeamRCB.json";
	String json=new String(Files.readAllBytes(Paths.get(file)));
    JsonPath js= new JsonPath(json);
    List<String> countries= new ArrayList<String>();
    for(int i=0;i<js.getInt("player.size()");i++) {
    	countries.add(js.getString("player["+i+"].country"));
    }
    int count =0;
    Iterator<String> it = countries.iterator();
    while(it.hasNext()) {
    	if(it.next().toString().equalsIgnoreCase("India")) {
    		count+=1;
    	}
    }
	Assert.assertTrue("Team RCB has more than 4 foriegn players please modify the team", count==7);
}
}
